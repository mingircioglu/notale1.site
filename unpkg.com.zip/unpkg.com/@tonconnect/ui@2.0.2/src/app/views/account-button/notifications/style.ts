import { css } from 'solid-styled-components';

export const NotificationClass = css`
    transform: translateY(-8px);
    margin-bottom: 12px;
`;
